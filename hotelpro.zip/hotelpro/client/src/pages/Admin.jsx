import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { fmtDate, inr } from '../utils';
import { Status } from './MyBookings';

const emptyRoom = { number: '', type: 'single', pricePerNight: '', capacity: 1, amenities: '', description: '', image: '' };

export default function Admin() {
  const [tab, setTab] = useState('bookings');
  const [stats, setStats] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [filter, setFilter] = useState('');
  const [room, setRoom] = useState(emptyRoom);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      const [s, b, r] = await Promise.all([
        api.get('/bookings/stats'),
        api.get(`/bookings${filter ? `?status=${filter}` : ''}`),
        api.get('/rooms'),
      ]);
      setStats(s.data); setBookings(b.data); setRooms(r.data);
    } catch (e) { setError(errMsg(e)); }
  };
  useEffect(() => { load(); }, [filter]);

  const act = async (fn) => { setError(''); try { await fn(); await load(); } catch (e) { setError(errMsg(e)); } };

  const addRoom = (e) => {
    e.preventDefault();
    act(async () => {
      await api.post('/rooms', { ...room, amenities: room.amenities.split(',').map((a) => a.trim()).filter(Boolean) });
      setRoom(emptyRoom);
    });
  };

  const set = (k) => (e) => setRoom({ ...room, [k]: e.target.value });

  return (
    <div className="container py-4">
      <h2 className="mb-3">Hotel dashboard</h2>
      {stats && (
        <div className="row g-3 mb-4">
          {[['Active rooms', stats.rooms], ['In house now', stats.occupied], ['Arrivals booked', stats.upcoming], ['Revenue collected', inr(stats.revenue)]].map(([l, v]) => (
            <div className="col-6 col-md-3" key={l}><div className="stat"><b>{v}</b>{l}</div></div>
          ))}
        </div>
      )}
      {error && <div className="alert alert-danger">{error}</div>}
      <ul className="nav nav-tabs mb-3">
        {['bookings', 'rooms'].map((t) => <li className="nav-item" key={t}><button className={`nav-link text-capitalize ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>{t}</button></li>)}
      </ul>

      {tab === 'bookings' && (
        <>
          <select className="form-select w-auto mb-3" aria-label="Filter by status" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">All statuses</option><option value="confirmed">Confirmed</option><option value="checked-in">Checked in</option>
            <option value="checked-out">Checked out</option><option value="cancelled">Cancelled</option>
          </select>
          <div className="table-responsive">
            <table className="table align-middle bg-white">
              <thead><tr><th>Guest</th><th>Room</th><th>Stay</th><th>Total</th><th>Status</th><th>Payment</th><th /></tr></thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b._id}>
                    <td>{b.user?.name}<br /><small className="text-muted">{b.user?.email}</small></td>
                    <td className="text-capitalize">{b.room?.number} ({b.room?.type})</td>
                    <td>{fmtDate(b.checkIn)} to {fmtDate(b.checkOut)}</td>
                    <td>{inr(b.totalPrice)}</td>
                    <td><Status value={b.status} /></td>
                    <td><Status value={b.paymentStatus} /></td>
                    <td className="text-end">
                      {b.status === 'confirmed' && <button className="btn btn-sm btn-primary me-1" onClick={() => act(() => api.patch(`/bookings/${b._id}/check-in`))}>Check in</button>}
                      {b.status === 'checked-in' && <button className="btn btn-sm btn-brass" onClick={() => act(() => api.patch(`/bookings/${b._id}/check-out`))}>Check out</button>}
                    </td>
                  </tr>
                ))}
                {!bookings.length && <tr><td colSpan="7" className="text-muted">No bookings match this filter.</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === 'rooms' && (
        <div className="row g-4">
          <div className="col-lg-7 table-responsive">
            <table className="table align-middle bg-white">
              <thead><tr><th>Room</th><th>Type</th><th>Price</th><th>Sleeps</th><th /></tr></thead>
              <tbody>
                {rooms.map((r) => (
                  <tr key={r._id}><td>{r.number}</td><td className="text-capitalize">{r.type}</td><td>{inr(r.pricePerNight)}</td><td>{r.capacity}</td>
                    <td className="text-end"><button className="btn btn-sm btn-outline-danger" onClick={() => window.confirm(`Remove room ${r.number} from listings?`) && act(() => api.delete(`/rooms/${r._id}`))}>Remove</button></td></tr>
                ))}
              </tbody>
            </table>
          </div>
          <form className="col-lg-5" onSubmit={addRoom}>
            <h5>Add a room</h5>
            <div className="row g-2">
              <div className="col-6"><label className="form-label small" htmlFor="rn">Room number</label><input id="rn" className="form-control" value={room.number} onChange={set('number')} required /></div>
              <div className="col-6"><label className="form-label small" htmlFor="rt">Type</label>
                <select id="rt" className="form-select" value={room.type} onChange={set('type')}><option>single</option><option>double</option><option>deluxe</option><option>suite</option></select></div>
              <div className="col-6"><label className="form-label small" htmlFor="rp">Price per night (INR)</label><input id="rp" type="number" min="0" className="form-control" value={room.pricePerNight} onChange={set('pricePerNight')} required /></div>
              <div className="col-6"><label className="form-label small" htmlFor="rc">Sleeps</label><input id="rc" type="number" min="1" className="form-control" value={room.capacity} onChange={set('capacity')} required /></div>
              <div className="col-12"><label className="form-label small" htmlFor="ra">Amenities (comma separated)</label><input id="ra" className="form-control" value={room.amenities} onChange={set('amenities')} /></div>
              <div className="col-12"><label className="form-label small" htmlFor="ri">Image URL</label><input id="ri" className="form-control" value={room.image} onChange={set('image')} /></div>
              <div className="col-12"><label className="form-label small" htmlFor="rd">Description</label><textarea id="rd" className="form-control" rows="2" value={room.description} onChange={set('description')} /></div>
              <div className="col-12"><button className="btn btn-primary">Add room</button></div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
