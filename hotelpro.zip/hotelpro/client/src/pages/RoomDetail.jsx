import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import { inr, isoDay, nightsBetween } from '../utils';

export default function RoomDetail() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [room, setRoom] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ checkIn: params.get('checkIn') || isoDay(1), checkOut: params.get('checkOut') || isoDay(2), guests: params.get('guests') || 1 });

  useEffect(() => { api.get(`/rooms/${id}`).then((r) => setRoom(r.data)).catch((e) => setError(errMsg(e))); }, [id]);

  const nights = nightsBetween(f.checkIn, f.checkOut);

  const book = async (e) => {
    e.preventDefault();
    if (!user) return navigate('/login', { state: { from: `/rooms/${id}?${new URLSearchParams(f)}` } });
    setBusy(true);
    setError('');
    try {
      await api.post('/bookings', { roomId: id, ...f });
      navigate('/my-bookings');
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  if (!room) return <div className="container py-5">{error ? <div className="alert alert-danger">{error}</div> : 'Loading room…'}</div>;

  return (
    <div className="container py-4">
      <div className="row g-4">
        <div className="col-lg-7">
          <img src={room.image} alt={`Room ${room.number}`} className="img-fluid rounded mb-3" />
          <h2 className="text-capitalize">{room.type} · Room {room.number}</h2>
          <p className="text-muted">Sleeps up to {room.capacity}</p>
          <p>{room.description}</p>
          <div>{room.amenities.map((a) => <span key={a} className="amenity">{a}</span>)}</div>
        </div>
        <div className="col-lg-5">
          <form className="border rounded p-4 bg-white" onSubmit={book}>
            <div className="price fs-3 mb-3">{inr(room.pricePerNight)}<small className="text-muted fw-normal fs-6"> / night</small></div>
            {error && <div className="alert alert-danger py-2">{error}</div>}
            <label className="form-label" htmlFor="ci">Check-in</label>
            <input id="ci" type="date" className="form-control mb-3" min={isoDay()} value={f.checkIn} onChange={(e) => setF({ ...f, checkIn: e.target.value })} required />
            <label className="form-label" htmlFor="co">Check-out</label>
            <input id="co" type="date" className="form-control mb-3" min={f.checkIn} value={f.checkOut} onChange={(e) => setF({ ...f, checkOut: e.target.value })} required />
            <label className="form-label" htmlFor="g">Guests</label>
            <input id="g" type="number" min="1" max={room.capacity} className="form-control mb-3" value={f.guests} onChange={(e) => setF({ ...f, guests: e.target.value })} required />
            {nights > 0 && <p className="d-flex justify-content-between"><span>{nights} night{nights > 1 && 's'}</span><b>{inr(nights * room.pricePerNight)}</b></p>}
            <button className="btn btn-primary w-100" disabled={busy || nights < 1}>{user ? 'Confirm booking' : 'Log in to book'}</button>
          </form>
        </div>
      </div>
    </div>
  );
}
