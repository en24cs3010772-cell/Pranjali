import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api, { errMsg } from '../api';
import RoomCard from '../components/RoomCard';
import SearchForm from '../components/SearchForm';

export default function Rooms() {
  const [params] = useSearchParams();
  const [rooms, setRooms] = useState(null);
  const [error, setError] = useState('');
  const query = params.toString();
  const keep = new URLSearchParams([...params].filter(([k]) => ['checkIn', 'checkOut', 'guests'].includes(k)));

  useEffect(() => {
    setRooms(null);
    setError('');
    api.get(`/rooms?${query}`).then((r) => setRooms(r.data)).catch((e) => setError(errMsg(e)));
  }, [query]);

  return (
    <div className="container py-4">
      <h2 className="mb-3">Available rooms</h2>
      <SearchForm initial={Object.fromEntries(params)} />
      <div className="row g-4 mt-1">
        {error && <div className="alert alert-danger">{error}</div>}
        {!rooms && !error && <p>Loading rooms…</p>}
        {rooms?.length === 0 && <p className="text-muted">No rooms are free for those dates. Try different dates or a different room type.</p>}
        {rooms?.map((r) => <div key={r._id} className="col-md-6 col-lg-4"><RoomCard room={r} query={keep.toString() ? `?${keep}` : ''} /></div>)}
      </div>
    </div>
  );
}
