import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { fmtDate, inr } from '../utils';

export const Status = ({ value }) => <span className={`status status-${value}`}>{value}</span>;

export default function MyBookings() {
  const [bookings, setBookings] = useState(null);
  const [error, setError] = useState('');
  const [method, setMethod] = useState({});

  const load = () => api.get('/bookings/mine').then((r) => setBookings(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const act = async (id, action, body) => {
    setError('');
    try { await api.patch(`/bookings/${id}/${action}`, body); await load(); } catch (e) { setError(errMsg(e)); }
  };

  if (!bookings) return <div className="container py-5">{error || 'Loading your bookings…'}</div>;

  return (
    <div className="container py-4">
      <h2 className="mb-3">My bookings</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {bookings.length === 0 && <p className="text-muted">You have no bookings yet. <Link to="/rooms">Find a room</Link></p>}
      <div className="row g-3">
        {bookings.map((b) => (
          <div className="col-md-6" key={b._id}>
            <div className="border rounded bg-white p-3">
              <div className="d-flex justify-content-between">
                <h5 className="text-capitalize mb-1">{b.room?.type} · Room {b.room?.number}</h5>
                <Status value={b.status} />
              </div>
              <p className="mb-1">{fmtDate(b.checkIn)} to {fmtDate(b.checkOut)} ({b.nights} night{b.nights > 1 && 's'}, {b.guests} guest{b.guests > 1 && 's'})</p>
              <p className="mb-2"><b>{inr(b.totalPrice)}</b> <Status value={b.paymentStatus} /></p>
              <div className="d-flex gap-2 flex-wrap">
                {b.paymentStatus === 'pending' && b.status !== 'cancelled' && (
                  <>
                    <select className="form-select form-select-sm w-auto" aria-label="Payment method" value={method[b._id] || 'card'} onChange={(e) => setMethod({ ...method, [b._id]: e.target.value })}>
                      <option value="card">Card</option><option value="upi">UPI</option><option value="cash">Pay at hotel (cash)</option>
                    </select>
                    <button className="btn btn-sm btn-primary" onClick={() => act(b._id, 'pay', { method: method[b._id] || 'card' })}>Pay {inr(b.totalPrice)}</button>
                  </>
                )}
                {b.status === 'confirmed' && <button className="btn btn-sm btn-outline-danger" onClick={() => window.confirm('Cancel this booking?') && act(b._id, 'cancel')}>Cancel booking</button>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
