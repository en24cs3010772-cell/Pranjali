import { useEffect, useState } from 'react';
import api from '../api';
import RoomCard from '../components/RoomCard';
import SearchForm from '../components/SearchForm';

export default function Home() {
  const [rooms, setRooms] = useState([]);
  useEffect(() => { api.get('/rooms').then((r) => setRooms(r.data.slice(0, 3))).catch(() => {}); }, []);

  return (
    <>
      <section className="hero">
        <div className="container">
          <h1>Book a room that is actually free.</h1>
          <p className="fs-5 mt-3">Pick your dates and we show only the rooms available for them, with the full price up front.</p>
          <SearchForm />
        </div>
      </section>
      <section className="container py-5">
        <h2 className="mb-4">Rooms guests book most</h2>
        <div className="row g-4">
          {rooms.map((r) => <div key={r._id} className="col-md-4"><RoomCard room={r} /></div>)}
          {!rooms.length && <p className="text-muted">No rooms listed yet. Run <code>npm run seed</code> in the server folder to add sample rooms.</p>}
        </div>
      </section>
    </>
  );
}
