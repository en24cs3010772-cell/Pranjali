import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { errMsg } from '../api';

export default function Auth({ mode }) {
  const isLogin = mode === 'login';
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [f, setF] = useState({ name: '', email: '', phone: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const user = await (isLogin ? login({ email: f.email, password: f.password }) : register(f));
      navigate(location.state?.from || (user.role === 'admin' ? '/admin' : '/my-bookings'), { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container py-5" style={{ maxWidth: 440 }}>
      <h2 className="mb-4">{isLogin ? 'Log in' : 'Create your account'}</h2>
      <form onSubmit={submit}>
        {error && <div className="alert alert-danger py-2">{error}</div>}
        {!isLogin && (
          <>
            <label className="form-label" htmlFor="name">Full name</label>
            <input id="name" className="form-control mb-3" value={f.name} onChange={set('name')} required />
            <label className="form-label" htmlFor="phone">Phone (optional)</label>
            <input id="phone" className="form-control mb-3" value={f.phone} onChange={set('phone')} />
          </>
        )}
        <label className="form-label" htmlFor="email">Email</label>
        <input id="email" type="email" className="form-control mb-3" value={f.email} onChange={set('email')} required />
        <label className="form-label" htmlFor="password">Password</label>
        <input id="password" type="password" minLength={6} className="form-control mb-3" value={f.password} onChange={set('password')} required />
        <button className="btn btn-primary w-100" disabled={busy}>{isLogin ? 'Log in' : 'Create account'}</button>
      </form>
      <p className="mt-3 small">
        {isLogin ? <>New here? <Link to="/register">Create an account</Link></> : <>Already registered? <Link to="/login">Log in</Link></>}
      </p>
    </div>
  );
}
