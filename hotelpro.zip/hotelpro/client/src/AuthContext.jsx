import { createContext, useContext, useEffect, useState } from 'react';
import api from './api';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore the session from the stored JWT
  useEffect(() => {
    if (!localStorage.getItem('hotelpro_token')) return setLoading(false);
    api.get('/auth/me')
      .then((res) => setUser(res.data))
      .catch(() => localStorage.removeItem('hotelpro_token'))
      .finally(() => setLoading(false));
  }, []);

  const authenticate = async (path, body) => {
    const { data } = await api.post(`/auth/${path}`, body);
    localStorage.setItem('hotelpro_token', data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('hotelpro_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login: (b) => authenticate('login', b), register: (b) => authenticate('register', b), logout }}>
      {children}
    </AuthContext.Provider>
  );
}
