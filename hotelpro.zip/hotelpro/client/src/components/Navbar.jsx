import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="navbar navbar-expand-md site-nav">
      <div className="container">
        <Link to="/" className="brand">Hotel<span>Pro</span></Link>
        <button className="navbar-toggler border-secondary" data-bs-toggle="collapse" data-bs-target="#nav" aria-label="Toggle menu">
          <span className="navbar-toggler-icon" style={{ filter: 'invert(1)' }} />
        </button>
        <div className="collapse navbar-collapse" id="nav">
          <ul className="navbar-nav ms-auto align-items-md-center">
            <li className="nav-item"><NavLink className="nav-link" to="/rooms">Rooms</NavLink></li>
            {user && <li className="nav-item"><NavLink className="nav-link" to="/my-bookings">My bookings</NavLink></li>}
            {user?.role === 'admin' && <li className="nav-item"><NavLink className="nav-link" to="/admin">Admin</NavLink></li>}
            {user ? (
              <li className="nav-item ms-md-3">
                <button className="btn btn-sm btn-outline-light" onClick={() => { logout(); navigate('/'); }}>Log out ({user.name.split(' ')[0]})</button>
              </li>
            ) : (
              <>
                <li className="nav-item"><NavLink className="nav-link" to="/login">Log in</NavLink></li>
                <li className="nav-item ms-md-2"><Link className="btn btn-sm btn-brass" to="/register">Create account</Link></li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
