import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { isoDay } from '../utils';

export default function SearchForm({ initial = {} }) {
  const navigate = useNavigate();
  const [f, setF] = useState({ checkIn: initial.checkIn || isoDay(1), checkOut: initial.checkOut || isoDay(2), guests: initial.guests || 1, type: initial.type || '' });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    const q = new URLSearchParams(Object.entries(f).filter(([, v]) => v !== ''));
    navigate(`/rooms?${q}`);
  };

  return (
    <form className="search-plate row g-2 align-items-end" onSubmit={submit}>
      <div className="col-6 col-md"><label className="form-label small mb-1" htmlFor="ci">Check-in</label>
        <input id="ci" type="date" className="form-control" min={isoDay()} value={f.checkIn} onChange={set('checkIn')} required /></div>
      <div className="col-6 col-md"><label className="form-label small mb-1" htmlFor="co">Check-out</label>
        <input id="co" type="date" className="form-control" min={f.checkIn} value={f.checkOut} onChange={set('checkOut')} required /></div>
      <div className="col-6 col-md-2"><label className="form-label small mb-1" htmlFor="g">Guests</label>
        <input id="g" type="number" min="1" max="6" className="form-control" value={f.guests} onChange={set('guests')} /></div>
      <div className="col-6 col-md-2"><label className="form-label small mb-1" htmlFor="t">Room type</label>
        <select id="t" className="form-select" value={f.type} onChange={set('type')}>
          <option value="">Any</option><option value="single">Single</option><option value="double">Double</option>
          <option value="deluxe">Deluxe</option><option value="suite">Suite</option>
        </select></div>
      <div className="col-12 col-md-auto"><button className="btn btn-primary w-100">Find available rooms</button></div>
    </form>
  );
}
