import { Link } from 'react-router-dom';
import { inr } from '../utils';

export default function RoomCard({ room, query = '' }) {
  return (
    <div className="room-card">
      <img src={room.image} alt={`Room ${room.number}, ${room.type}`} loading="lazy" />
      <div className="p-3 d-flex flex-column flex-grow-1">
        <div className="d-flex justify-content-between align-items-baseline">
          <h5 className="mb-1 text-capitalize">{room.type} · {room.number}</h5>
          <span className="price">{inr(room.pricePerNight)}<small className="text-muted fw-normal"> / night</small></span>
        </div>
        <p className="small text-muted mb-2">Sleeps {room.capacity}</p>
        <p className="mb-2">{room.description}</p>
        <div className="mb-3">{room.amenities.map((a) => <span key={a} className="amenity">{a}</span>)}</div>
        <Link to={`/rooms/${room._id}${query}`} className="btn btn-outline-primary mt-auto">View room and book</Link>
      </div>
    </div>
  );
}
