const router = require('express').Router();
const c = require('../controllers/roomController');
const { protect, adminOnly } = require('../middleware/auth');

router.get('/', c.getRooms);
router.get('/:id', c.getRoom);
router.post('/', protect, adminOnly, c.createRoom);
router.put('/:id', protect, adminOnly, c.updateRoom);
router.delete('/:id', protect, adminOnly, c.deleteRoom);

module.exports = router;
