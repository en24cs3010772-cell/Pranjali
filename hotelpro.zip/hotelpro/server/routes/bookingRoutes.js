const router = require('express').Router();
const c = require('../controllers/bookingController');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect);
router.post('/', c.createBooking);
router.get('/mine', c.myBookings);
router.get('/stats', adminOnly, c.stats);
router.get('/', adminOnly, c.allBookings);
router.patch('/:id/cancel', c.cancelBooking);
router.patch('/:id/pay', c.payBooking);
router.patch('/:id/check-in', adminOnly, c.checkIn);
router.patch('/:id/check-out', adminOnly, c.checkOut);

module.exports = router;
