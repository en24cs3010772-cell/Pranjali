require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Room = require('./models/Room');
const Booking = require('./models/Booking');

const img = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=900&q=70`;

const rooms = [
  { number: '101', type: 'single', pricePerNight: 1800, capacity: 1, amenities: ['Wi-Fi', 'AC', 'Desk'], description: 'Compact room for solo travellers, with a work desk and a quiet courtyard view.', image: img('photo-1631049307264-da0ec9d70304') },
  { number: '102', type: 'single', pricePerNight: 2000, capacity: 1, amenities: ['Wi-Fi', 'AC', 'Tea maker'], description: 'Bright single room on the ground floor, close to the lobby.', image: img('photo-1522771739844-6a9f6d5f14af') },
  { number: '201', type: 'double', pricePerNight: 3200, capacity: 2, amenities: ['Wi-Fi', 'AC', 'TV', 'Mini fridge'], description: 'Queen bed, sitting corner and a window over the garden.', image: img('photo-1590490360182-c33d57733427') },
  { number: '202', type: 'double', pricePerNight: 3400, capacity: 3, amenities: ['Wi-Fi', 'AC', 'TV', 'Extra bed'], description: 'Room for a small family, with an extra bed on request.', image: img('photo-1566665797739-1674de7a421a') },
  { number: '301', type: 'deluxe', pricePerNight: 5200, capacity: 3, amenities: ['Wi-Fi', 'AC', 'Bathtub', 'Balcony'], description: 'Corner room with a private balcony and a soaking tub.', image: img('photo-1611892440504-42a792e24d32') },
  { number: '401', type: 'suite', pricePerNight: 9500, capacity: 4, amenities: ['Wi-Fi', 'AC', 'Lounge', 'Kitchenette', 'Balcony'], description: 'Top-floor suite with a separate lounge and kitchenette.', image: img('photo-1578683010236-d716f9a3f461') },
];

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany(), Room.deleteMany(), Booking.deleteMany()]);
  await User.create([
    { name: 'Hotel Admin', email: 'admin@hotelpro.com', password: 'admin123', role: 'admin' },
    { name: 'Demo Guest', email: 'guest@hotelpro.com', password: 'guest123' },
  ]);
  await Room.insertMany(rooms);
  console.log('Seeded. Admin: admin@hotelpro.com / admin123   Guest: guest@hotelpro.com / guest123');
  process.exit(0);
})();
