const Room = require('../models/Room');
const Booking = require('../models/Booking');
const { asyncHandler, httpError } = require('../middleware/error');

const ACTIVE = ['confirmed', 'checked-in'];

// IDs of rooms that already have a booking overlapping [checkIn, checkOut)
async function bookedRoomIds(checkIn, checkOut) {
  return Booking.distinct('room', {
    status: { $in: ACTIVE },
    checkIn: { $lt: checkOut },
    checkOut: { $gt: checkIn },
  });
}

exports.bookedRoomIds = bookedRoomIds;

exports.getRooms = asyncHandler(async (req, res) => {
  const { type, maxPrice, guests, checkIn, checkOut } = req.query;
  const filter = { isActive: true };
  if (type) filter.type = type;
  if (maxPrice) filter.pricePerNight = { $lte: Number(maxPrice) };
  if (guests) filter.capacity = { $gte: Number(guests) };

  if (checkIn && checkOut) {
    const a = new Date(checkIn);
    const b = new Date(checkOut);
    if (isNaN(a) || isNaN(b) || b <= a) throw httpError(400, 'Check-out must be after check-in');
    filter._id = { $nin: await bookedRoomIds(a, b) };
  }
  res.json(await Room.find(filter).sort({ pricePerNight: 1 }));
});

exports.getRoom = asyncHandler(async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) throw httpError(404, 'Room not found');
  res.json(room);
});

exports.createRoom = asyncHandler(async (req, res) => {
  res.status(201).json(await Room.create(req.body));
});

exports.updateRoom = asyncHandler(async (req, res) => {
  const room = await Room.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!room) throw httpError(404, 'Room not found');
  res.json(room);
});

exports.deleteRoom = asyncHandler(async (req, res) => {
  // Soft delete keeps past bookings intact
  const room = await Room.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
  if (!room) throw httpError(404, 'Room not found');
  res.json({ message: 'Room removed from listings' });
});
