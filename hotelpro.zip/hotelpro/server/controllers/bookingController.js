const Booking = require('../models/Booking');
const Room = require('../models/Room');
const User = require('../models/User');
const { bookedRoomIds } = require('./roomController');
const { asyncHandler, httpError } = require('../middleware/error');

const DAY = 24 * 60 * 60 * 1000;
const populate = (q) => q.populate('room', 'number type image pricePerNight').populate('user', 'name email');

exports.createBooking = asyncHandler(async (req, res) => {
  const { roomId, checkIn, checkOut, guests } = req.body;
  const a = new Date(checkIn);
  const b = new Date(checkOut);
  const today = new Date().setHours(0, 0, 0, 0);

  if (isNaN(a) || isNaN(b)) throw httpError(400, 'Valid check-in and check-out dates are required');
  if (a < today) throw httpError(400, 'Check-in cannot be in the past');
  if (b <= a) throw httpError(400, 'Check-out must be after check-in');

  const room = await Room.findOne({ _id: roomId, isActive: true });
  if (!room) throw httpError(404, 'Room not found');
  const g = Number(guests) || 1;
  if (g > room.capacity) throw httpError(400, `This room sleeps up to ${room.capacity} guests`);

  const taken = await bookedRoomIds(a, b);
  if (taken.some((id) => id.equals(room._id))) throw httpError(409, 'Room is not available for those dates');

  const nights = Math.round((b - a) / DAY);
  const booking = await Booking.create({
    user: req.user._id,
    room: room._id,
    checkIn: a,
    checkOut: b,
    guests: g,
    nights,
    totalPrice: nights * room.pricePerNight,
  });
  res.status(201).json(await populate(Booking.findById(booking._id)));
});

exports.myBookings = asyncHandler(async (req, res) => {
  res.json(await populate(Booking.find({ user: req.user._id }).sort({ createdAt: -1 })));
});

exports.allBookings = asyncHandler(async (req, res) => {
  const filter = req.query.status ? { status: req.query.status } : {};
  res.json(await populate(Booking.find(filter).sort({ checkIn: -1 })));
});

async function loadOwned(req) {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw httpError(404, 'Booking not found');
  const isOwner = booking.user.equals(req.user._id);
  if (!isOwner && req.user.role !== 'admin') throw httpError(403, 'Not your booking');
  return booking;
}

exports.cancelBooking = asyncHandler(async (req, res) => {
  const booking = await loadOwned(req);
  if (booking.status !== 'confirmed') throw httpError(400, `A ${booking.status} booking cannot be cancelled`);
  booking.status = 'cancelled';
  if (booking.paymentStatus === 'paid') booking.paymentStatus = 'refunded';
  await booking.save();
  res.json(booking);
});

// Simulated payment: records the method and marks the booking paid.
// Swap this for Stripe/Razorpay when going live.
exports.payBooking = asyncHandler(async (req, res) => {
  const booking = await loadOwned(req);
  const { method } = req.body;
  if (!['card', 'upi', 'cash'].includes(method)) throw httpError(400, 'Choose card, upi or cash');
  if (booking.status === 'cancelled') throw httpError(400, 'Cancelled bookings cannot be paid');
  if (booking.paymentStatus === 'paid') throw httpError(400, 'Already paid');
  booking.paymentStatus = 'paid';
  booking.paymentMethod = method;
  booking.paidAt = new Date();
  await booking.save();
  res.json(booking);
});

exports.checkIn = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw httpError(404, 'Booking not found');
  if (booking.status !== 'confirmed') throw httpError(400, 'Only confirmed bookings can check in');
  booking.status = 'checked-in';
  await booking.save();
  res.json(booking);
});

exports.checkOut = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) throw httpError(404, 'Booking not found');
  if (booking.status !== 'checked-in') throw httpError(400, 'Guest has not checked in');
  booking.status = 'checked-out';
  if (booking.paymentStatus === 'pending') {
    booking.paymentStatus = 'paid';
    booking.paymentMethod = booking.paymentMethod || 'cash';
    booking.paidAt = new Date();
  }
  await booking.save();
  res.json(booking);
});

exports.stats = asyncHandler(async (req, res) => {
  const now = new Date();
  const [rooms, guests, occupied, revenue] = await Promise.all([
    Room.countDocuments({ isActive: true }),
    User.countDocuments({ role: 'guest' }),
    Booking.countDocuments({ status: 'checked-in' }),
    Booking.aggregate([{ $match: { paymentStatus: 'paid' } }, { $group: { _id: null, total: { $sum: '$totalPrice' } } }]),
  ]);
  const upcoming = await Booking.countDocuments({ status: 'confirmed', checkIn: { $gte: now } });
  res.json({ rooms, guests, occupied, upcoming, revenue: revenue[0]?.total || 0 });
});
