const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { asyncHandler, httpError } = require('../middleware/error');

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

const payload = (user) => ({
  token: signToken(user._id),
  user: { id: user._id, name: user.name, email: user.email, phone: user.phone, role: user.role },
});

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) throw httpError(400, 'Name, email and password are required');
  // Role is never taken from the request body: public sign-ups are always guests.
  const user = await User.create({ name, email, password, phone });
  res.status(201).json(payload(user));
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw httpError(400, 'Email and password are required');
  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.matchPassword(password))) throw httpError(401, 'Incorrect email or password');
  res.json(payload(user));
});

exports.me = asyncHandler(async (req, res) => {
  const u = req.user;
  res.json({ id: u._id, name: u.name, email: u.email, phone: u.phone, role: u.role });
});
