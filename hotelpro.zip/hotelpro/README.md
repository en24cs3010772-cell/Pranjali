# HotelPro

Hotel booking and management system built with the MERN stack and JWT authentication.

**Guests** search by date, see only rooms that are free for those dates, book, pay and cancel.
**Admins** manage rooms, check guests in and out, and see occupancy and revenue.

## Tech stack
React (Vite), React Router, Bootstrap 5, Node.js, Express, MongoDB (Mongoose), JSON Web Tokens, bcrypt.

## Prerequisites
Node.js v16+, npm v8+, MongoDB running locally (or a MongoDB Atlas URI), Git.

## Setup

```bash
# 1. Backend
cd server
npm install
cp .env.example .env        # then set JWT_SECRET (and MONGO_URI if not local)
npm run seed                # sample rooms + demo accounts
npm run dev                 # http://localhost:5000

# 2. Frontend (new terminal)
cd client
npm install
npm run dev                 # http://localhost:5173
```

Demo accounts created by the seed script:

| Role  | Email               | Password  |
|-------|---------------------|-----------|
| Admin | admin@hotelpro.com  | admin123  |
| Guest | guest@hotelpro.com  | guest123  |

## API

| Method | Endpoint | Access | Purpose |
|--------|----------|--------|---------|
| POST | `/api/auth/register` | Public | Create a guest account |
| POST | `/api/auth/login` | Public | Log in, returns JWT |
| GET | `/api/auth/me` | User | Current user |
| GET | `/api/rooms` | Public | List rooms. Filters: `checkIn`, `checkOut`, `guests`, `type`, `maxPrice` |
| GET | `/api/rooms/:id` | Public | Room details |
| POST / PUT / DELETE | `/api/rooms[/:id]` | Admin | Add, edit, remove rooms |
| POST | `/api/bookings` | User | Create a booking (checks availability) |
| GET | `/api/bookings/mine` | User | My bookings |
| PATCH | `/api/bookings/:id/pay` | Owner | Pay (simulated) |
| PATCH | `/api/bookings/:id/cancel` | Owner/Admin | Cancel (refunds if paid) |
| GET | `/api/bookings` | Admin | All bookings, optional `?status=` |
| PATCH | `/api/bookings/:id/check-in` | Admin | Check a guest in |
| PATCH | `/api/bookings/:id/check-out` | Admin | Check a guest out |
| GET | `/api/bookings/stats` | Admin | Dashboard numbers |

## Project structure

```
hotelpro/
├── server/   config, models (User, Room, Booking), middleware (auth, errors),
│             controllers, routes, seed.js, server.js
└── client/   src/pages, src/components, AuthContext, api client
```

## Security notes
Passwords are hashed with bcrypt, routes are protected with JWT, roles are enforced on the server (new accounts are always guests), and `helmet` and CORS are enabled. Payment is simulated; connect a gateway such as Stripe or Razorpay before real use.
